# BuckIt
Do stuf --> Make Friends

## Proposal
Share your bucket list with your friends, team up to accomplish activities, or just keep track of the adventures you want to take!

